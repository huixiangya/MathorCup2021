import pandas as pd
data=pd.read_csv('data/sum.csv')
temp=[[name[0],name[1],len(group)] for name,group in data.groupby(['registerYear','modelyear'])]
data_re = pd.DataFrame(temp,columns=['registerYear','modelyear','count'])

outputpath='data/modelyear.csv'
data_re.to_csv(outputpath,sep=',',index=False,header=False)

print(data_re)