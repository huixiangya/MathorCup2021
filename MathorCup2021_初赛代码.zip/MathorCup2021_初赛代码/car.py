import warnings
warnings.filterwarnings('ignore')
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

import missingno as msno    #缺失值可视化
import seaborn as sns
sns.set(style='white',context='notebook',palette='muted')

train=pd.read_csv('data/price_train.csv')
test=pd.read_csv('data/price_test.csv')

##3.理解数据
print('实验数据大小：',train.shape)
print('测试数据大小：',test.shape)

#print(train.describe())
print(train.info())
#print(train.head())
#cityId_price=train.groupby('cityId')['price'].mean()
#print(cityId_price)

#判断数据缺失和异常
print(train.isnull().sum())
print(test.isnull().sum())

missing=train.isnull().sum()
missing=missing[missing>0]
missing.sort_values(inplace=True)
missing.plot.bar()
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False
plt.title('缺失值统计')
plt.xticks(rotation=90) # 旋转90度
plt.savefig(r"data/img/缺失值条形图.png")
msno.matrix(train.sample(250))

plt.title('缺失值可视化')
plt.savefig(r"data/img/缺失值可视化.png")

