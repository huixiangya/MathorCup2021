import warnings

from numpy.ma import count

warnings.filterwarnings('ignore')
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib


import seaborn as sns
sns.set(style='darkgrid',context='notebook',palette='muted')
from scipy import stats
from scipy.stats import norm
from scipy.stats import skew

from collections import Counter



full_data=pd.read_csv('data/full_data.csv')
corrDf=pd.DataFrame()
plt.figure(figsize=(15,12))
corrDf=full_data.corr()
#print(corrDf)
#print(full_data.columns)
#outputpath='data/corrDf.csv'
#corrDf.to_csv(outputpath,sep=',',index=False,header=False)

matplotlib.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
#sns.heatmap(train_corr,square=True,vmax=0.8,cmap='RdBu')
#plt.title('数据相关性',fontsize='xx-large',fontweight='heavy')
#plt.savefig(r"data/img/完整数据相关性.png")
#plt.show()


####探索性数据分析
#车价分布----有明显的正偏度，需做对数处理
sale_price=pd.DataFrame(full_data['sales_price'])
#正常图
fig = plt.figure(figsize=(10,6))
sns.displot(sale_price,kde=True)
plt.xlim(-50,150)
plt.title('二手车价格分布')
#plt.savefig(r"data/img/sales_price.png",dpi=600)
#plt.show()

plt.figure(figsize=(10,10))
top_cols=corrDf['sales_price'].nlargest(10).index   #相关性最高的10个行索引
train_corr_top=full_data.loc[:,top_cols].corr()
sns.heatmap(train_corr_top,annot=True,square=True,fmt='.2f',cmap='RdBu',vmax=0.8)
#plt.savefig(r"data/img/相关性最大的前10可视化.png")
#plt.show()


#绘制网格图，查看相关性
cols=['newprice','displacement','AF2','maketype','modelyear','registerYear']
sns.pairplot(full_data[cols],size=2.5)
#plt.savefig(r"data/img/不同特征的散点图pairplot.png",dpi=600)
#plt.show()

###数值型特征对数变换
numeric_df=full_data.select_dtypes(['float64','int32','int64'])
numeric_cols=numeric_df.columns.tolist()
#print(numeric_cols)
fig=plt.figure(figsize=(30,20))
# for col in numeric_cols:
#     ax=fig.add_subplot(4,6,numeric_cols.index(col)+1)   #add_subplot(nrows, ncols, index, **kwargs)
#     ax.set_xlabel(col)
#     ax.hist(numeric_df[col])
# plt.savefig(r"data/img/数值型数据直方图.png")
#plt.show()

#计算各特征维度偏度
skewed_cols=full_data[numeric_cols].apply(lambda x:skew(x)).sort_values(ascending=False)
skewed_df=pd.DataFrame({'skew':skewed_cols})
#print(skewed_df)

##对绝对值>0.5的特征对数变换
skew_cols=skewed_df[skewed_df['skew'].abs()>1].index.tolist()
for col in skew_cols:
    full_data[col]=np.log1p(full_data[col])
 #   sns.distplot(full_data[col], fit=norm)
 #   plt.savefig(r"data/img/%s.png"%full_data[col])

##二手车价格的对数变换
sale_price = np.log1p(full_data['sales_price'])
sns.distplot(sale_price, fit=norm)
fig = plt.figure()
res = stats.probplot(sale_price, plot=plt)
plt.savefig(r"房价的对数变换.png")
#plt.show()
#
# for i in range(len(full_data['l_rDate'])):
#     if full_data['l_rDate'] < 0:
#         full_data['l_rDate']=0

#all_mis_val = calc_mis_val(full_data)
#print(all_mis_val)


##建模
from sklearn.linear_model import RidgeCV
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from lightgbm import LGBMRegressor
from xgboost import XGBRegressor
from sklearn.svm import SVR
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import RobustScaler
from sklearn.model_selection import KFold, GridSearchCV, cross_val_score, train_test_split
from sklearn.metrics import mean_squared_error
from sklearn import linear_model
from sklearn import metrics
from sklearn.linear_model import Ridge
from sklearn.ensemble import BaggingRegressor
from sklearn.ensemble import AdaBoostRegressor


#建模之前，先划分数据集，定义交叉验证模式以及衡量指标
# 划分数据集
full_data=pd.read_csv('data/full_data.csv')
train=full_data[full_data['sales_price'].notnull()]
testall=full_data[full_data['sales_price'].isnull()]
X = train.drop(columns='sales_price')
y = train['sales_price']
test_X=testall.drop(columns='sales_price')
test_X_df=pd.DataFrame(test_X)


# 定义衡量指标函数
def rmse(y, y_pred):
    rmse = np.sqrt(mean_squared_error(y, y_pred))
    return rmse

def mae(ytest,y_pred):
    mae=metrics.mean_absolute_error(ytest, y_pred)
    return mae

def cv_rmse(model, X=X):
    rmse = np.sqrt(-cross_val_score(model, X, y, scoring='neg_mean_squared_error', cv=kf))
    return rmse

def cv_mae(model, X=X):
    mae = np.sqrt(-cross_val_score(model, X, y, scoring='neg_mean_absolute_error', cv=kf))
    return mae

#MAPE
def mape(y_true, y_pred):
    return(np.average(np.abs(y_true - y_pred) / y_true, axis=0))

# APE
def ape(y_true, y_pred):
    return np.mean(np.abs((y_pred - y_true) / y_true))


Xtrain, Xtest, ytrain, ytest = train_test_split(X, y, test_size=0.3, random_state=10)
#定义交叉验证模式(10折交叉验证)
kf = KFold(n_splits=10, random_state=50, shuffle=True)

###AdaBoostRegressor
# ridge = Ridge(alpha = 15)
# from sklearn.ensemble import AdaBoostRegressor
# params = [10,15,20,25,30,35,40,45,50]
# test_scores = []
# for param in params:
#     clf = AdaBoostRegressor(base_estimator = ridge,n_estimators = param)
#     test_score = np.sqrt(-cross_val_score(clf,Xtrain,ytrain,cv = 10,scoring = 'neg_mean_squared_error'))
#     test_scores.append(np.mean(test_score))
# plt.plot(params,test_scores)
# plt.title('n_estimators vs CV Error')
# plt.show
#
# br = BaggingRegressor(base_estimator = ridge,n_estimators = 25)
# br.fit(Xtrain,ytrain)
# y_final = br.predict(Xtest)

#####XGBRegressor
# from xgboost import XGBRegressor
# params = [1,2,3,4,5,6]
# test_scores = []
# for param in params:
#     clf = XGBRegressor(max_depth = param)
#     test_score = np.sqrt(-cross_val_score(clf,Xtrain,ytrain,cv = 10,scoring = 'neg_mean_squared_error'))
#     test_scores.append(np.mean(test_score))
# plt.plot(params,test_scores)
# plt.title('max_depth vs CV Error')
# plt.show()


# bagging 把很多小的分类器放在一起，每个train随机的一部分数据，然后把它们的最终结果综合起来（多数投票）
# bagging 算是一种算法框架
ridge = Ridge(alpha = 15)

params = [1,10,15,20,25,30,40]
test_scores = []
for param in params:
    clf = BaggingRegressor(base_estimator = ridge,n_estimators = param)
    test_score = np.sqrt(-cross_val_score(clf,Xtrain,ytrain,cv = 10,scoring = 'neg_mean_squared_error'))
    test_scores.append(np.mean(test_score))

plt.plot(params,test_scores)
plt.title('n_estimators vs CV Error')
plt.show()

br = BaggingRegressor(base_estimator = ridge,n_estimators = 25)
br.fit(Xtrain,ytrain)
y_final = np.expm1(br.predict(Xtest))





xgb = XGBRegressor(max_depth = 5)
xgb.fit(Xtrain, ytrain)
y_final = np.expm1(xgb.predict(Xtest))

##accurancy
def accurancy(y_true, y_pred):
    ape_ = np.average(np.abs(y_true - y_pred) / y_true, axis=0)
    Accurancy5=count(ape_<0.05)/30000
    return Accurancy5


def count_(y_true, y_pred):
    ape_ = np.average(np.abs(y_true - y_pred) / y_true, axis=0)
    count1=count(ape_<0.05)
    return count1

count2=count_(ytest, y_final)
print('count:%f'%count2)

mape1=mape(ytest, y_final)
print('models_mape_value:%f'%mape1)

accurancy1=accurancy(ytest, y_final)
print('models_accurancy:%f'%accurancy1)
evaluate1=0.2*(1-mape1)+0.8*accurancy1
print('模型精度：%f'%evaluate1)
##boosting