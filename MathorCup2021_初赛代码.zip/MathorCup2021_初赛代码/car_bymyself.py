import warnings

from numpy.ma import count

warnings.filterwarnings('ignore')
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib

import missingno as msno    #缺失值可视化
import seaborn as sns
sns.set(style='darkgrid',context='notebook',palette='muted')
from scipy import stats
from scipy.stats import norm
from scipy.stats import skew

from collections import Counter



train=pd.read_csv('data/price_train.csv')
test=pd.read_csv('data/price_test.csv')
#train.drop(columns='carid',inplace=True)
#test.drop(columns='carid',inplace=True)
#print('删除Id列实验数据大小：',train.shape)
#print('删除Id列测试数据大小：',test.shape)

#concat train+test
all_data=pd.concat([train,test],axis=0,ignore_index=True)

#Save the column label and delete it to facilitate data cleaning.
sale_price=train['price']
all_data.drop(columns='price',inplace=True)
#print('合并训练测试数据大小：',all_data.shape)

#all_data.info()
#print(all_data.describe())
#correlationship
plt.figure(figsize=(15,12))
train_corr=train.corr()
sns.heatmap(train_corr,square=True,vmax=0.8,cmap='RdBu')
#plt.savefig(r"data/img/相关性分析表.png")
#plt.show()

#####二.数据清洗
###1.缺失值处理
def calc_mis_val(df):
    cols = df.columns
    mis_val=df.isnull().sum()
    mis_val_pct=round(100*mis_val/df.shape[0],2)
    print(df.shape[0])
    mis_val_df=pd.DataFrame({'mis_val':mis_val, 'mis_val_pct(%)':mis_val_pct}, index=cols)
    mis_val_df = mis_val_df[mis_val_df['mis_val'] != 0].sort_values('mis_val', ascending=False)

#    print('总列数：', df.shape[1])
#    print('含缺失值列数：', mis_val_df.shape[0])
    return mis_val_df

#all_mis_val = calc_mis_val(all_data)
#print(all_mis_val)
#outputpath='data/缺失值统计.csv'
#all_mis_val.to_csv(outputpath,sep=',',index=True,header=True)


# ##缺失值处理
##carcode填充
#print(all_data['carCode'].value_counts())
all_data['carCode'] = all_data['carCode'].fillna('1')

##gearbox填充
#print(all_data['gearbox'].value_counts())
all_data['gearbox'] = all_data['gearbox'].fillna('3')

##AF12填充
#print(all_data['AF12'].value_counts())
all_data['AF12'] = all_data['AF12'].fillna('4783*1810*1442')


##modelyear填充（核验）
all_data['modelyear'] = all_data.groupby('registerYear')['modelyear'].transform(lambda x: x.fillna(x.mode()[0]))


##AF15,AF7,AF4移除(将缺失30%+的值移除)
all_data = all_data.drop(columns=['AF15','AF7','AF4','AF12'])
all_mis_val = calc_mis_val(all_data)

##RF填充缺失8列---maketype
cou_pre = all_data[['maketype','brand','model','color','cityId','carCode','transferCount','seatings','gearbox']]
#print(cou_pre)
cou_pre = pd.get_dummies(cou_pre)
gearbox_cou = pd.get_dummies(cou_pre['brand'],prefix='brand')
cou_pre_corr=pd.DataFrame()
cou_pre_corr=cou_pre.corr()
#print(cou_pre_corr['maketype'].sort_values())

cou_pre = all_data[['maketype','cityId','carCode','seatings','gearbox']]
###拆分数据并建立模型 split the data and build a model
maket_know=cou_pre[cou_pre['maketype'].notnull()]
maket_unknow=cou_pre[cou_pre['maketype'].isnull()]
maket_know_X=maket_know.drop(['maketype'],axis=1)
maket_know_Y=maket_know['maketype']
maket_unknow_X=maket_unknow.drop(['maketype'],axis=1)
from sklearn.ensemble import RandomForestRegressor
rfr=RandomForestRegressor(random_state=None,n_estimators=500,n_jobs=-1)
rfr.fit(maket_know_X,maket_know_Y)

##use the model to predict and fill the result into the source dataset
#print(rfr.score(maket_know_X,maket_know_Y))

###预测maketype
maket_unknow_Y=rfr.predict(maket_unknow_X)
all_data.loc[all_data['maketype'].isnull(),['maketype']]=maket_unknow_Y

full=all_data.drop(['country','AF1','AF8','AF9','AF10','AF11','AF13'],axis=1)
#all_mis_val = calc_mis_val(full)

###查看各个特征与标签相关性
full2 = pd.concat([full,sale_price],axis=1)
all_mis_val = calc_mis_val(full2)
outputpath='data/full_data_idcar.csv'
full2.to_csv(outputpath,sep=',',index=False,header=False)


##整理好的数据
full_data=pd.read_csv('data/full_data.csv')
corrDf=pd.DataFrame()
plt.figure(figsize=(15,12))
corrDf=full_data.corr()
#print(corrDf)
#print(full_data.columns)
#outputpath='data/corrDf.csv'
#corrDf.to_csv(outputpath,sep=',',index=False,header=False)

matplotlib.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
sns.heatmap(train_corr,square=True,vmax=0.8,cmap='RdBu')
#plt.title('数据相关性',fontsize='xx-large',fontweight='heavy')
#plt.savefig(r"data/img/完整数据相关性.png")
#plt.show()


####探索性数据分析
#车价分布----有明显的正偏度，需做对数处理
sale_price=pd.DataFrame(full_data['sales_price'])
#正常图
fig = plt.figure(figsize=(10,6))
sns.displot(sale_price,kde=True)
plt.xlim(-50,150)
plt.title('二手车价格分布')
#plt.savefig(r"data/img/sales_price.png",dpi=600)
#plt.show()

plt.figure(figsize=(10,10))
top_cols=corrDf['sales_price'].nlargest(10).index   #相关性最高的10个行索引
train_corr_top=full_data.loc[:,top_cols].corr()
sns.heatmap(train_corr_top,annot=True,square=True,fmt='.2f',cmap='RdBu',vmax=0.8)
#plt.savefig(r"data/img/相关性最大的前10可视化.png")
#plt.show()


#绘制网格图，查看相关性
cols=['newprice','displacement','AF2','maketype','modelyear','registerYear']
sns.pairplot(full_data[cols],size=2.5)
#plt.savefig(r"data/img/不同特征的散点图pairplot.png",dpi=600)
#plt.show()

###数值型特征对数变换
numeric_df=full_data.select_dtypes(['float64','int32','int64'])
numeric_cols=numeric_df.columns.tolist()
#print(numeric_cols)
fig=plt.figure(figsize=(30,20))
# for col in numeric_cols:
#     ax=fig.add_subplot(4,6,numeric_cols.index(col)+1)   #add_subplot(nrows, ncols, index, **kwargs)
#     ax.set_xlabel(col)
#     ax.hist(numeric_df[col])
# plt.savefig(r"data/img/数值型数据直方图.png")
#plt.show()

#计算各特征维度偏度
skewed_cols=full_data[numeric_cols].apply(lambda x:skew(x)).sort_values(ascending=False)
skewed_df=pd.DataFrame({'skew':skewed_cols})
#print(skewed_df)

##对绝对值>0.5的特征对数变换
skew_cols=skewed_df[skewed_df['skew'].abs()>1].index.tolist()
for col in skew_cols:
    full_data[col]=np.log1p(full_data[col])
 #   sns.distplot(full_data[col], fit=norm)
 #   plt.savefig(r"data/img/%s.png"%full_data[col])

##二手车价格的对数变换
sale_price = np.log1p(full_data['sales_price'])
sns.distplot(sale_price, fit=norm)
fig = plt.figure()
res = stats.probplot(sale_price, plot=plt)
plt.savefig(r"房价的对数变换.png")
#plt.show()
#
# for i in range(len(full_data['l_rDate'])):
#     if full_data['l_rDate'] < 0:
#         full_data['l_rDate']=0

all_mis_val = calc_mis_val(full_data)
#print(all_mis_val)


##建模
from sklearn.linear_model import RidgeCV
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from lightgbm import LGBMRegressor
from xgboost import XGBRegressor
from sklearn.svm import SVR
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import RobustScaler
from sklearn.model_selection import KFold, GridSearchCV, cross_val_score, train_test_split
from sklearn.metrics import mean_squared_error
from sklearn import linear_model
from sklearn import metrics

#建模之前，先划分数据集，定义交叉验证模式以及衡量指标
# 划分数据集
full_data=pd.read_csv('data/full_data.csv')
train=full_data[full_data['sales_price'].notnull()]
testall=full_data[full_data['sales_price'].isnull()]
X = train.drop(columns='sales_price')
y = train['sales_price']
test_X=testall.drop(columns='sales_price')
test_X_df=pd.DataFrame(test_X)


# 定义衡量指标函数
def rmse(y, y_pred):
    rmse = np.sqrt(mean_squared_error(y, y_pred))
    return rmse

def mae(ytest,y_pred):
    mae=metrics.mean_absolute_error(ytest, y_pred)
    return mae

def cv_rmse(model, X=X):
    rmse = np.sqrt(-cross_val_score(model, X, y, scoring='neg_mean_squared_error', cv=kf))
    return rmse

def cv_mae(model, X=X):
    mae = np.sqrt(-cross_val_score(model, X, y, scoring='neg_mean_absolute_error', cv=kf))
    return mae

#MAPE
def mape(y_true, y_pred):
    return(np.average(np.abs(y_true - y_pred) / y_true, axis=0))

# APE
def ape(y_true, y_pred):
    return np.mean(np.abs((y_pred - y_true) / y_true))


Xtrain, Xtest, ytrain, ytest = train_test_split(X, y, test_size=0.3, random_state=10)
#定义交叉验证模式(10折交叉验证)
kf = KFold(n_splits=10, random_state=50, shuffle=True)

# 建立基线模型

lgb = LGBMRegressor(objective='regression', random_state=50)
xgb = XGBRegressor(objective='reg:squarederror', random_state=50)
ridge = make_pipeline(RobustScaler(), RidgeCV(cv=kf))
svr = make_pipeline(RobustScaler(), SVR())
gbr = GradientBoostingRegressor(random_state=50)
rf = RandomForestRegressor(random_state=50)

models = [lgb, xgb, rf, ridge, gbr, svr]
model_names = ['lgb', 'xgb', 'rf', 'ridge', 'gbr', 'svr']
scores = {}

for i, model in enumerate(models):
    score = cv_mae(model)
#    print('{} mae score: {:.4f}, mae std: {:.4f}'.format(model_names[i], score.mean(), score.std()))
    scores[model_names[i]] = (score.mean(), score.std())

mae_df = pd.DataFrame(scores, index=['mae_score', 'mae_std'])
mae_df.sort_values('mae_score', axis=1, inplace=True)
print(mae_df)

####Stacking
# 定义StackingRegressor类
class StackingRegressor(object):

    def __init__(self, fir_models, fir_model_names, sec_model, cv):
        self.fir_models = fir_models
        self.fir_model_names = fir_model_names
        self.sec_model = sec_model
        self.cv = cv

    def fit_predict(self, X, y, test):

        stacked_train = pd.DataFrame()
        stacked_test = pd.DataFrame()

        n_fold = 0

        for i, model in enumerate(self.fir_models):

            stacked_train[self.fir_model_names[i]] = np.zeros(shape=(X.shape[0],))

            for train_index, valid_index in self.cv.split(X):
                n_fold += 1
                stacked_test[self.fir_model_names[i]] = np.zeros(shape=(test.shape[0],))

                X_train, y_train = X.iloc[train_index, :], y.iloc[train_index]
                X_valid, y_valid = X.iloc[valid_index, :], y.iloc[valid_index]

                model.fit(X_train, y_train)
                stacked_train.loc[valid_index, self.fir_model_names[i]] = model.predict(X_valid)
                stacked_test.loc[:, self.fir_model_names[i]] = model.predict(test)
                print(model.predict(test))
                # sys.exit()
            print('{} is done.'.format(self.fir_model_names[i]))

        y.reset_index(drop=True, inplace=True)
        stacked_train['y_true'] = y

        """
        for i, model_name in enumerate(self.fir_model_names):
            stacked_test[model_name] = stacked_test.iloc[:, :10].mean(axis=1)
            stacked_test.drop(stacked_test.iloc[:, :10], axis=1, inplace=True)
        """

#        print('----stacked_train----\n', stacked_train)
#        print('----stacked_test----\n', stacked_test)

        self.sec_model.fit(stacked_train.drop(columns='y_true'), stacked_train['y_true'])
        y_pred = self.sec_model.predict(stacked_test)
        return y_pred


sr = StackingRegressor(models, model_names, xgb, cv=kf)
stacking_pred = sr.fit_predict(Xtrain, ytrain, Xtest)
#
#stacking_score = rmse(ytest, stacking_pred)
#print(stacking_score)
ape1 = metrics.mean_absolute_error(ytest, stacking_pred)
print('models_mae_value:%f'%ape1)

# #APE
# def ape(y_true, y_pred,):
#     return(np.average(np.abs(y_true - y_pred) / y_true, axis=0))
# ape=ape(ytest, stacking_pred)
# print('sr_ape_value:%f'%ape)


# # MAPE
# def mape(y_true, y_pred):
#     return np.mean(np.abs((y_pred - y_true) / y_true))
mape1=mape(ytest, stacking_pred)
print('models_mape_value:%f'%mape1)

##accurancy
def accurancy(y_true, y_pred):
    ape_ = np.average(np.abs(y_true - y_pred) / y_true, axis=0)
    Accurancy5=count(ape_<0.05)/30000
    return Accurancy5


accurancy1=accurancy(ytest, stacking_pred)
print('models_accurancy:%f'%accurancy1)
evaluate1=0.2*(1-mape1)+0.8*accurancy1
print('模型精度：%f'%evaluate1)

# 模型融合：blending
def blending(X, y, test):
    lgb.fit(X, y)
    lgb_pred = lgb.predict(test)

    xgb.fit(X, y)
    xgb_pred = xgb.predict(test)

    ridge.fit(X, y)
    ridge_pred = ridge.predict(test)

    svr.fit(X, y)
    svr_pred = svr.predict(test)

    gbr.fit(X, y)
    gbr_pred = gbr.predict(test)

    rf.fit(X, y)
    rf_pred = rf.predict(test)

    sr = StackingRegressor(models, model_names, xgb, kf)
    sr_pred = sr.fit_predict(X, y, test)
    print()
    # 加权求和
    blended_pred = (0.2 * lgb_pred +
                    0.2 * xgb_pred +
#                    0.2 * ridge_pred +
#                    0.25 * svr_pred +
 #                   0.2* gbr_pred +
                    0.4 * rf_pred+
                    0.2 * sr_pred)
    return blended_pred



blended_pred = blending(Xtrain, ytrain, Xtest)
#blending_score = rmse(ytest, blended_pred)
ape2 = metrics.mean_absolute_error(ytest, blended_pred)
print('sr_ape_score:%f'%ape2)

mape2=mape(ytest, blended_pred)
print('sr_mape_value:%f'%mape2)

accurancy5=accurancy(ytest, blended_pred)
print('sr_accurancy:%f'%accurancy5)
evaluate1=0.2*(1-mape2)+0.8*accurancy5
print('模型精度：%f'%evaluate1)


# 预测并提交结果
#y_pred = np.exp(blending(X, y, test_X)) - 1
y_pred = blending(X, y, test_X)
#print(y_pred)
# sample = pd.read_csv('data/sample_submission.csv')
# sample['SalePrice'] = y_pred
# sample.to_csv('data/result.csv')

# #column=['idcar','SalePrice'] #列表头名称
# df1 = pd.Series(y_pred)
# df2 = pd.DataFrame(test_X)
# data=pd.concat([df2,df1],axis=1)
# #test=pd.DataFrame(data=data)#将数据放进表格
# data.to_csv('data/result.csv')

sub = pd.DataFrame()
#sub['SaleID'] = test_X['idcar']
sub['price'] = y_pred
sub.to_csv('data/sample_submission.csv')