import numpy as np
import pandas as pd
import os,sys
from sklearn.linear_model import RidgeCV
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from lightgbm import LGBMRegressor
from xgboost import XGBRegressor
from sklearn.svm import SVR
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import RobustScaler
from sklearn.model_selection import KFold, GridSearchCV, cross_val_score, train_test_split
from sklearn.metrics import mean_squared_error
from sklearn import linear_model
from sklearn import metrics

full_data=pd.read_csv('data/full_data.csv')
train=full_data[full_data['sales_price'].notnull()]
testall=full_data[full_data['sales_price'].isnull()]
X = train.drop(columns='sales_price')
y = train['sales_price']
test_X=testall.drop(columns='sales_price')


def rmse(y, y_pred):
    rmse = np.sqrt(mean_squared_error(y, y_pred))
    return rmse

def cv_rmse(model, X=X):
    rmse = np.sqrt(-cross_val_score(model, X, y, scoring='neg_mean_squared_error', cv=kf))
    return rmse

Xtrain, Xtest, ytrain, ytest = train_test_split(X, y, test_size=0.3, random_state=10)

kf = KFold(n_splits=10, random_state=50, shuffle=True)


lgb = LGBMRegressor(objective='regression', random_state=50)
xgb = XGBRegressor(objective='reg:squarederror', random_state=50)
ridge = make_pipeline(RobustScaler(), RidgeCV(cv=kf))
svr = make_pipeline(RobustScaler(), SVR())
gbr = GradientBoostingRegressor(random_state=50)
rf = RandomForestRegressor(random_state=50)

models = [lgb, xgb, rf, ridge, gbr, svr]
model_names = ['lgb', 'xgb', 'rf', 'ridge', 'gbr', 'svr']
scores = {}

class StackingRegressor(object):
    
    def __init__(self, fir_models, fir_model_names, sec_model, cv):
        self.fir_models = fir_models
        self.fir_model_names = fir_model_names
        self.sec_model = sec_model
        self.cv = cv
    
    def fit_predict(self, X, y, test):   

        stacked_train = pd.DataFrame()
        stacked_test = pd.DataFrame()

        n_fold = 0


        for i, model in enumerate(self.fir_models):
 
            stacked_train[self.fir_model_names[i]] = np.zeros(shape=(X.shape[0], ))


            for train_index, valid_index in self.cv.split(X):

                n_fold += 1
                stacked_test[self.fir_model_names[i]] = np.zeros(shape=(test.shape[0], ))


                X_train, y_train = X.iloc[train_index, :], y.iloc[train_index]
                X_valid, y_valid = X.iloc[valid_index, :], y.iloc[valid_index]

   
                model.fit(X_train, y_train)
                stacked_train.loc[valid_index, self.fir_model_names[i]] = model.predict(X_valid)
                stacked_test.loc[:, self.fir_model_names[i]] = model.predict(test)
                #print(model.predict(test))
                #sys.exit()
            print('{} is done.'.format(self.fir_model_names[i]))


        y.reset_index(drop=True, inplace=True)
        stacked_train['y_true'] = y

        """
        for i, model_name in enumerate(self.fir_model_names):
            stacked_test[model_name] = stacked_test.iloc[:, :10].mean(axis=1)
            stacked_test.drop(stacked_test.iloc[:, :10], axis=1, inplace=True)
        """
        
 
        print('----stacked_train----\n', stacked_train)
        print('----stacked_test----\n', stacked_test)
        

        self.sec_model.fit(stacked_train.drop(columns='y_true'), stacked_train['y_true'])
        y_pred = self.sec_model.predict(stacked_test)
        return y_pred


sr = StackingRegressor(models, model_names, xgb, cv=kf)
stacking_pred = sr.fit_predict(Xtrain, ytrain, Xtest)
stacking_score = rmse(ytest, stacking_pred)
print(stacking_score)


mae = metrics.mean_absolute_error(ytest, stacking_pred)
print(mae)

# 模型融合：blending
def blending(X, y, test):
    lgb.fit(X, y)
    lgb_pred = lgb.predict(test)

    xgb.fit(X, y)
    xgb_pred = xgb.predict(test)

    ridge.fit(X, y)
    ridge_pred = ridge.predict(test)

    svr.fit(X, y)
    svr_pred = svr.predict(test)

    gbr.fit(X, y)
    gbr_pred = gbr.predict(test)

    rf.fit(X, y)
    rf_pred = rf.predict(test)

    sr = StackingRegressor(models, model_names, xgb, kf)
    sr_pred = sr.fit_predict(X, y, test)

    # 加权求和
    blended_pred = (0.3 * lgb_pred +
                    0.3 * xgb_pred +
#                    0.2 * ridge_pred +
#                    0.25 * svr_pred +
#                    0.25 * gbr_pred +
                    0.4 * rf_pred)
#                    0.2 * sr_pred)
    return blended_pred

blended_pred = blending(Xtrain, ytrain, Xtest)
#blending_score = rmse(ytest, blended_pred)
blending_score = metrics.mean_absolute_error(ytest, blended_pred)
print(blending_score)